package com.brnprog.habits_app_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HabitsAppBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(HabitsAppBackendApplication.class, args);
	}

}
